var app=angular.module("app",[])
.controller("myController",function($scope,$http){

	$scope.getProductList = function(){
		   $http.get('http://localhost:8080/hello/getProductsList').success(function (data){
		       $scope.products = data;
		   });
		};
});
