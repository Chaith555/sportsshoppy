package com.niit.services;

import java.util.List;



import com.niit.model.Product;

public interface ProductService {
	List<Product> getAllProducts();
	Product getProductBypid(int pid);
	void addProduct(Product product);
	
	void deleteProduct(int pid);
	void editProduct(Product product);
}
