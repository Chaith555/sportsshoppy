package com.niit.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.ProductDao;
import com.niit.model.Product;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductDao productDao;

	public ProductDao getProductDao() {
		return productDao;
	}

	@Transactional
	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	@Transactional
	public List<Product> getAllProducts() {
		return productDao.getAllProducts();
	}

	@Transactional
	public Product getProductByPid(int pid) {
		return productDao.getProductBypid(pid);
	}
	@Transactional
	public void addProduct(Product product) {
		productDao.addProduct(product);
		
	}

	public void deleteProduct(int pid) {
		productDao.deleteProduct(pid);

	}

	public void editProduct(Product product) {
		productDao.editProduct(product);
		
	}

	@Override
	public Product getProductBypid(int pid) {
		// TODO Auto-generated method stub
		return null;
	}


}