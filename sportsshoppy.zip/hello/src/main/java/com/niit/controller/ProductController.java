package com.niit.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.model.Category;
import com.niit.model.Product;
import com.niit.services.ProductService;



@Controller
@Transactional
public class ProductController {
	
	@Autowired
	private ProductService productService;
	

	public ProductService getProductService() {
		return productService;
	}

	public void setProductService(ProductService productService) {
		this.productService = productService;
	}

	@RequestMapping("/getAllProductsList")
	public @ResponseBody List<Product>  getProductsInJSON(){
	return productService.getAllProducts();	
	}
	@RequestMapping("/getAllProducts")
	public ModelAndView getAllProduct() {
		List<Product> products = productService.getAllProducts();
		return new ModelAndView("productList", "products", products);
	}

	@RequestMapping("/getProductBypid/{pid}")
	public ModelAndView getProductBypid(@PathVariable(value = "pid") int pid) {
		Product p = productService.getProductBypid(pid);
		return new ModelAndView("productPage", "productObj", p);
	}
	@RequestMapping(value="/admin/product/addProduct{pid}",method=RequestMethod.GET)
	public String getProductForm(Model model){

		Product product=new Product();
		Category category=new Category();
		category.setCid(1);
		product.setCategory(category);
		
		model.addAttribute("productFormObj",product);
		return "productForm";
		
	}
	@RequestMapping(value="/admin/product/addProduct",method=RequestMethod.POST)
	public String addProduct(@Valid@ModelAttribute(value="productFormObj")  Product product,BindingResult result){

		if(result.hasErrors())			
			return "productForm";
			productService.addProduct(product);
			MultipartFile image=product.getProductImage();
			if(image!=null&& !image.isEmpty()){
			Path path=Paths.get("C:/workspace/hello/src/main/webapp/resources/img/" + product.getPid() + ".jpg");
			try {
				image.transferTo(new File(path.toString()));
			} 
			catch (IllegalStateException e) {
				
				e.printStackTrace();
			} 
			catch (IOException e) {
				
				e.printStackTrace();
			}
		}
			System.out.println("hi");
			return "redirect:/productsListAnguler";

}
	@RequestMapping("/delete/{pid}")
	public String deleteProduct(@PathVariable(value="pid")int pid){
		Path path=Paths.get("C:/workspace/hello/src/main/webapp/resources/img/" + pid + ".jpg");
		if(Files.exists(path))
				{
			try {
						Files.delete(path);
					} catch (IOException e) {
						
						e.printStackTrace();
					}
				}

	productService.deleteProduct(pid);
	return "redirect:/productsListAnguler";
}
	@RequestMapping("/admin/product/editProduct/{pid}")
	public ModelAndView getEditForm(@PathVariable(value="pid")  int pid){

		Product product=this.productService.getProductBypid(pid);
		return new ModelAndView("editProductForm","editProductObj",product);
	}
	@RequestMapping(value="/admin/product/editProduct",method=RequestMethod.POST)
	public String editProduct(@ModelAttribute(value="editProductObj") Product product)
	{
	productService.editProduct(product);
	return "redirect:/productsListAnguler";

	}
//	<!-- angular-->
	@RequestMapping("/getProductsList")
	public@ResponseBody List<Product>getProductsListInJSON(){
		return productService.getAllProducts();
	}
	
	@RequestMapping("/productsListAnguler")
	public String getProducts(){
		return "productsListAnguler";
	}


}