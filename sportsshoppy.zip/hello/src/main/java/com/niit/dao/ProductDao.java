package com.niit.dao;

import java.util.List;

import com.niit.model.Product;

public interface ProductDao {
	List<Product> getAllProducts();
	Product getProductBypid(int pid);
	 
	void addProduct(Product product);
	
	void deleteProduct(int pid);
	void editProduct(Product product);

}
