package com.niit.dao;

import com.niit.model.Customer;

public interface CustomerDao {
	void addCustomer(Customer customer);

}
